<?php
 $db = mysqli_connect('localhost','root','','cakes') ;
 if(!$db){
       echo "unable to connect to database ";
 }

?>