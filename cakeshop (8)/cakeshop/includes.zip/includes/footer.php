  </div>
  
        <!-- /.container-fluid -->

        <!-- Sticky Footer -->
        <!-- <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © Your Website 2018</span>
            </div>
          </div>
        </footer> -->

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->


    <link rel="stylesheet" href="Cake_Page.css">
    <footer>
        <div class="footer">
            <div class="footer_social_media">
                <br>
                <h1>IIITDMJ Cake</h1>
                <ul class="footer_socila_media_ul">
                    <li><a href=""><img src="facebook.png" alt=""></a></li>
                    <li><a href=""><img src="instagram.png" alt=""></a></li>
                    <li><a href=""><img src="twitter.png" alt=""></a></li>
                    <li><a href=""><img src="quora.png" alt=""></a></li>
                </ul>
            </div>
           <div class="footer_catogarie_flex">
            <div class="footer_footer">
                <h4>Experience</h4>
                <ul>
                    <li><small>Chocolate</small></li>
                    <li><small>Butterscotch</small></li>
                    <li><small>Black Forest</small></li>
                    <li><small>Strawberry</small></li>
                </ul>
            </div>
            <div class="footer_footer">
                <h4>Special</h4>
                <ul>
                    <li><small>Birthday</small></li>
                    <li><small>Anniversary</small></li>
                    <li><small>Sibling</small></li>
                    <li><small>Cartoon</small></li>
                </ul>
            </div>
            
           </div>
        </div>
        <div class="copyright">
            <p>COPYRIGHT @ (Sadanand,Saurabh,Nidhi)_IIITDMJ</p>
        </div>
    </footer>



    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="includes/logout.php">Logout</a>
          </div>
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Page level plugin JavaScript-->
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>

    <!-- Demo scripts for this page-->
    <script src="js/demo/datatables-demo.js"></script>
    <script src="js/demo/chart-area-demo.js"></script>

  </body>

</html>
